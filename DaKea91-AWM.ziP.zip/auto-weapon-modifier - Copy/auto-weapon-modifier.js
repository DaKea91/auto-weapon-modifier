// Hook into the attack roll
Hooks.on("dnd5e.rollAttack", async (workflow) => {
  let roll = workflow.attackRoll;
  if (!roll) return;

  let actor = workflow.actor;
  let item = workflow.item;

  // Check if the item is a weapon and has the "degradable" tag
  if (item.data.type !== "weapon" || !item.getFlag("auto-weapon-modifier", "degradable")) return;

  // Natural 1 or 20: Decrease attack and damage bonuses by 1
  if (roll.dice[0].results[0].result === 1 || roll.dice[0].results[0].result === 20) {
    await modifyWeapon(item, -1);
    ui.notifications.info(`${item.name} is damaged and has lost 1 to hit and 1 to damage.`);
  }
});

// Modify the weapon's bonuses
async function modifyWeapon(item, delta) {
  let newAttackBonus = item.data.data.attackBonus + delta;
  let newDamageParts = item.data.data.damage.parts.map(part => [part[0], part[1] + delta]);

  // If the weapon reaches -5, destroy it
  if (newAttackBonus <= -5) {
    await item.delete();
    ui.notifications.info(`${item.name} has been destroyed.`);
    return;
  }

  // Update the weapon's data
  await item.update({
    "data.attackBonus": newAttackBonus,
    "data.damage.parts": newDamageParts
  });
}

// Create a chat command to repair the weapon
Hooks.on("chatMessage", async (chatLog, message, chatData) => {
  if (message.startsWith("/repair")) {
    let [_, weaponName] = message.split(" ");

    let actor = canvas.tokens.controlled[0]?.actor;
    if (!actor) {
      ui.notifications.warn("Please select a token.");
      return;
    }

    let item = actor.items.find(i => i.name === weaponName && i.type === "weapon");
    if (!item) {
      ui.notifications.warn("Weapon not found on selected actor.");
      return;
    }

    // Repair the weapon (increase attack and damage bonuses by 1)
    await modifyWeapon(item, 1);
    ui.notifications.info(`${weaponName} has been repaired by 1 to hit and 1 to damage.`);
  }
});