// Hook into the attack roll
Hooks.on("dnd5e.preRollAttack", (workflow) => {
  console.log("Attack roll detected", workflow);

  let roll = workflow.attackRoll;
  if (!roll) return;

  let actor = workflow.actor;
  let item = workflow.item;

  console.log("Actor:", actor);
  console.log("Item:", item);

  // Check if the item is a weapon and has the "degradable" tag
  if (item.type !== "weapon" || !item.getFlag("auto-weapon-modifier", "degradable")) {
    console.log("Item is not a degradable weapon.");
    return;
  }

  // Natural 1 or 20: Decrease attack and damage bonuses by 1
  if (roll.dice[0].results[0].result === 1 || roll.dice[0].results[0].result === 20) {
    console.log("Natural 1 or 20 rolled.");
    modifyWeapon(item, -1);
    ui.notifications.info(`${item.name} is damaged and has lost 1 to hit and 1 to damage.`);
  }
});

// Modify the weapon's bonuses
function modifyWeapon(item, delta) {
  console.log("Modifying weapon", item);

  let newAttackBonus = (item.system.attackBonus || 0) + delta;
  let newDamageParts = item.system.damage.parts.map(part => [part[0], (parseInt(part[1]) || 0) + delta]);

  console.log("New attack bonus:", newAttackBonus);
  console.log("New damage parts:", newDamageParts);

  // If the weapon reaches -5, destroy it
  if (newAttackBonus <= -5) {
    item.delete();
    ui.notifications.info(`${item.name} has been destroyed.`);
    return;
  }

  // Update the weapon's data
  item.update({
    "system.attackBonus": newAttackBonus,
    "system.damage.parts": newDamageParts
  });
}

// Create a chat command to repair the weapon
Hooks.on("chatMessage", (chatLog, message, chatData) => {
  if (message.startsWith("/repair")) {
    let [_, weaponName] = message.split(" ");

    let actor = canvas.tokens.controlled[0]?.actor;
    if (!actor) {
      ui.notifications.warn("Please select a token.");
      return;
    }

    let item = actor.items.find(i => i.name === weaponName && i.type === "weapon");
    if (!item) {
      ui.notifications.warn("Weapon not found on selected actor.");
      return;
    }

    // Repair the weapon (increase attack and damage bonuses by 1)
    modifyWeapon(item, 1);
    ui.notifications.info(`${weaponName} has been repaired by 1 to hit and 1 to damage.`);
  }
});